package com.RandomNumber;

public abstract class RandomNumberGenerator {
	 public abstract int generate();
	}

